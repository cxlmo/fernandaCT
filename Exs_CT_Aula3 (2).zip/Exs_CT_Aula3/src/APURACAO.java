
public class APURACAO {

	public static void main(String[] args) {
		
	}

}
